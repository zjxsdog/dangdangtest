-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2018 年 06 月 15 日 10:13
-- 服务器版本: 5.5.8
-- PHP 版本: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `dangdang`
--
CREATE DATABASE `dangdang` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `dangdang`;

-- --------------------------------------------------------

--
-- 表的结构 `book`
--

CREATE TABLE IF NOT EXISTS `book` (
  `side` tinyint(4) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `preprice` varchar(255) NOT NULL,
  PRIMARY KEY (`side`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- 转存表中的数据 `book`
--

INSERT INTO `book` (`side`, `url`, `title`, `price`, `preprice`) VALUES
(1, 'http://img3m0.ddimg.cn/26/27/25198100-1_u_3.jpg,http://img3m0.ddimg.cn/26/27/25198100-2_u_3.jpg,http://img3m0.ddimg.cn/26/27/25198100-3_u_3.jpg,http://img3m0.ddimg.cn/26/27/25198100-4_u_1.jpg', '飞花令里读诗词 邂逅古今文学 套装共6册 中国诗词大会通关宝典', '111.20', '¥598.00'),
(2, 'http://img3m8.ddimg.cn/74/32/25247648-1_u_9.jpg,http://img3m8.ddimg.cn/74/32/25247648-2_u_6.jpg,http://img3m8.ddimg.cn/74/32/25247648-3_u_6.jpg,http://img3m8.ddimg.cn/74/32/25247648-4_u_6.jpg,http://img3m8.ddimg.cn/74/32/25247648-5_u_6.jpg', '看世界（400张图看世界史，打通学科边界，为孩子开启博大、宏远的世界历史之窗）', '49.00', '¥98.00'),
(3, 'http://img3m8.ddimg.cn/94/32/22750888-1_u_2.jpg,http://img3m8.ddimg.cn/94/32/22750888-2_u_1.jpg,http://img3m8.ddimg.cn/94/32/22750888-3_u_1.jpg', '单反摄影宝典', '73.10', '¥89.00'),
(4, 'http://img3m8.ddimg.cn/43/2/25277218-1_u_4.jpg,http://img3m8.ddimg.cn/43/2/25277218-2_u_3.jpg,http://img3m8.ddimg.cn/43/2/25277218-3_u_3.jpg,http://img3m8.ddimg.cn/43/2/25277218-4_u_3.jpg,http://img3m8.ddimg.cn/43/2/25277218-5_u_4.jpg', '中国禅宗典籍丛刊（精装全10册）：赵州录、马祖语录、临济录、祖堂集、大慧书、正法眼藏、禅苑清规、禅源诸诠集都序、禅林僧宝传、敕修百丈清规', '295.00', '¥590.00'),
(5, 'http://img3m0.ddimg.cn/6/22/24012060-1_u_5.jpg', '非暴力沟通系列（《非暴力沟通》+《非暴力沟通实践手册》+《用非暴力沟通化解冲突》套装，共3册）', '87.90', '¥101.00'),
(6, 'http://img3m8.ddimg.cn/0/5/25243218-1_u_3.jpg,http://img3m8.ddimg.cn/0/5/25243218-2_u_3.jpg,http://img3m8.ddimg.cn/0/5/25243218-3_u_3.jpg', '美国人：从殖民到民主的历程(套装3册)', '144.00', '¥288.00');

-- --------------------------------------------------------

--
-- 表的结构 `book_ppt`
--

CREATE TABLE IF NOT EXISTS `book_ppt` (
  `sid` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `book_ppt`
--

INSERT INTO `book_ppt` (`sid`, `url`) VALUES
(1, 'http://img63.ddimg.cn/upload_img/00234/zzh/335x220_djj_0427-1524819556.jpg'),
(2, 'http://img53.ddimg.cn/9001530040033163.jpg'),
(3, 'http://img60.ddimg.cn/upload_img/00478/0609/335x220-0607-0608-1528427179.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `brand_logo`
--

CREATE TABLE IF NOT EXISTS `brand_logo` (
  `sid` tinyint(4) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

--
-- 转存表中的数据 `brand_logo`
--

INSERT INTO `brand_logo` (`sid`, `url`) VALUES
(1, 'http://img60.ddimg.cn/upload_img/00389/2/9154.jpg'),
(2, 'http://img60.ddimg.cn/upload_img/00389/NB/150911-11181pc-E.jpg'),
(3, 'http://img63.ddimg.cn/upload_img/00389/adidas/150911-11257pc-E.jpg'),
(4, 'http://img62.ddimg.cn/upload_img/00389/nike/150911-3957pc-E.jpg'),
(5, 'http://img60.ddimg.cn/upload_img/00389/2/9154.jpg'),
(6, 'http://img62.ddimg.cn/upload_img/00584/1/balabala-001.jpg'),
(7, 'http://img61.ddimg.cn/upload_img/00629/wenjing/tuomasi2-1519701357.jpg'),
(8, 'http://img61.ddimg.cn/upload_img/00629/wenjing/miqidingdang-1519701492.jpg'),
(9, 'http://img63.ddimg.cn/upload_img/00584/1/daiweibeila-004.jpg'),
(10, 'http://img63.ddimg.cn/upload_img/00584/1/daiweibeila-004.jpg'),
(11, 'http://img61.ddimg.cn/upload_img/00629/wenjing/dishini-1519701529.jpg'),
(12, 'http://img50.ddimg.cn/53840028943330_y.jpg'),
(13, 'http://img59.ddimg.cn/115130028482509_y.jpg'),
(14, 'http://img52.ddimg.cn/101880027093252_y.jpg'),
(15, 'http://img52.ddimg.cn/101880027093252_y.jpg'),
(16, 'http://img52.ddimg.cn/101880027093252_y.jpg'),
(17, 'http://img59.ddimg.cn/80380030650729_y.jpg'),
(18, 'http://img52.ddimg.cn/99610024249442_y.jpg'),
(19, 'http://img53.ddimg.cn/115630037876283_y.jpg'),
(20, 'http://img57.ddimg.cn/85250018753697_y.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `brand_logo2`
--

CREATE TABLE IF NOT EXISTS `brand_logo2` (
  `sid` tinyint(4) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- 转存表中的数据 `brand_logo2`
--

INSERT INTO `brand_logo2` (`sid`, `url`) VALUES
(1, 'http://img60.ddimg.cn/upload_img/00418/lisiyi/wd-8-11.png'),
(2, 'http://img61.ddimg.cn/2017/12/18/2017121813582854298.hp6LpZ2O'),
(3, 'http://img60.ddimg.cn/upload_img/00624/19900404/lili.png'),
(4, 'http://img59.ddimg.cn/179910025132119_y.png'),
(5, 'http://img60.ddimg.cn/upload_img/00443/0819/20160822-ry-05.png'),
(6, 'http://img60.ddimg.cn/2018/3/20/2018032019063736043.hpG6FK8Z'),
(7, 'http://img60.ddimg.cn/2017/8/21/2017082109264354456.hpwaSvJQ'),
(8, 'http://img53.ddimg.cn/87020034999573_y.jpg'),
(9, 'http://img62.ddimg.cn/2017/9/25/20170925155345899.hpUOvIjJ'),
(10, 'http://img52.ddimg.cn/196800028594712_y.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `clothes`
--

CREATE TABLE IF NOT EXISTS `clothes` (
  `sid` tinyint(4) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(250) NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `clothes`
--

INSERT INTO `clothes` (`sid`, `url`) VALUES
(1, 'http://img63.ddimg.cn/upload_img/00750/zhaoyu03/luotuo1-1526440710.jpg'),
(2, 'http://img50.ddimg.cn/85250030877100_y.jpg'),
(3, 'http://img56.ddimg.cn/53840039240636_y.jpg'),
(4, 'http://img52.ddimg.cn/107480039576512_y.jpg'),
(5, 'http://img53.ddimg.cn/203780040194123_y.jpg'),
(6, 'http://img52.ddimg.cn/213350030075602_y.jpg'),
(7, 'http://img51.ddimg.cn/212960079361661_y.jpg'),
(8, 'http://img61.ddimg.cn/upload_img/00673/0/aa-1520564637.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `clothes_ppt`
--

CREATE TABLE IF NOT EXISTS `clothes_ppt` (
  `sid` tinyint(4) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `clothes_ppt`
--

INSERT INTO `clothes_ppt` (`sid`, `url`) VALUES
(1, 'http://img57.ddimg.cn/165600047130407_y.jpg'),
(2, 'http://img52.ddimg.cn/207770044945732_y.jpg'),
(3, 'http://img60.ddimg.cn/upload_img/00727/123/PCda-1528683431.jpg'),
(4, 'http://img53.ddimg.cn/39570039471453_y.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `commodity`
--

CREATE TABLE IF NOT EXISTS `commodity` (
  `sid` tinyint(4) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `commodity`
--

INSERT INTO `commodity` (`sid`, `url`) VALUES
(1, 'http://img55.ddimg.cn/14540038518305_y.jpg'),
(2, 'http://img62.ddimg.cn/upload_img/00450/lily/0518-1526611748.jpg'),
(3, 'http://img63.ddimg.cn/upload_img/00624/19900404/8702-1527240747.jpg'),
(4, 'http://img63.ddimg.cn/2018/3/23/2018032315163566130.hpR9alY3'),
(5, 'http://img58.ddimg.cn/121110030310478_y.jpg'),
(6, 'http://img58.ddimg.cn/121110025267718_y.jpg'),
(7, 'http://img57.ddimg.cn/157400047119487_y.jpg'),
(8, 'http://img61.ddimg.cn/2018/5/10/2018051010175872555.hpDnNHOl');

-- --------------------------------------------------------

--
-- 表的结构 `dangdang_lunbo`
--

CREATE TABLE IF NOT EXISTS `dangdang_lunbo` (
  `side` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  PRIMARY KEY (`side`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=33 ;

--
-- 转存表中的数据 `dangdang_lunbo`
--

INSERT INTO `dangdang_lunbo` (`side`, `url`) VALUES
(1, 'http://img62.ddimg.cn/2018/6/8/201806081614575681.jpg'),
(2, 'http://img60.ddimg.cn/2018/6/8/201806081621383546.jpg'),
(3, 'http://img62.ddimg.cn/2018/6/8/2018060816513013230.jpg'),
(4, 'http://img62.ddimg.cn/2018/6/8/2018060814281596611.jpg'),
(5, 'http://img63.ddimg.cn/2018/6/8/201806081650007796.jpg'),
(6, 'http://img62.ddimg.cn/2018/6/8/201806081722097938.jpg'),
(7, 'http://img62.ddimg.cn/2018/6/8/2018060816463123118.jpg'),
(8, 'http://img60.ddimg.cn/2018/6/8/2018060815343312918.jpg'),
(31, 'http://img62.ddimg.cn/2018/6/8/2018060816463123118.jpg'),
(32, 'http://img60.ddimg.cn/2018/6/8/2018060815343312918.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `lunbo_low`
--

CREATE TABLE IF NOT EXISTS `lunbo_low` (
  `sid` tinyint(4) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `lunbo_low`
--

INSERT INTO `lunbo_low` (`sid`, `url`) VALUES
(1, 'http://img63.ddimg.cn/2018/6/8/2018060814284322928.jpg'),
(2, 'http://img62.ddimg.cn/2018/6/8/2018060817145717934.jpg'),
(3, 'http://img60.ddimg.cn/2018/6/8/2018060817133683612.jpg'),
(4, 'http://img63.ddimg.cn/2018/6/8/2018060817175383775.jpg'),
(5, 'http://img62.ddimg.cn/2018/6/8/2018060816152216177.jpg'),
(6, 'http://img60.ddimg.cn/2018/6/8/201806081622251195.jpg'),
(7, 'http://img63.ddimg.cn/2018/6/8/2018060816541583221.jpg'),
(8, 'http://img61.ddimg.cn/2018/6/8/2018060817124776677.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `lunbo_right`
--

CREATE TABLE IF NOT EXISTS `lunbo_right` (
  `sid` tinyint(4) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `lunbo_right`
--

INSERT INTO `lunbo_right` (`sid`, `url`) VALUES
(1, 'http://img62.ddimg.cn/upload_img/00750/zhaoyu03/TAP-1528430737.jpg'),
(2, 'http://img61.ddimg.cn/upload_img/00678/zsts/202x119_yyx_0601-1527840742.jpg'),
(3, 'http://img63.ddimg.cn/upload_img/00549/wuxian/1234-1518428055.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `miaosha`
--

CREATE TABLE IF NOT EXISTS `miaosha` (
  `sid` tinyint(4) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `preprice` varchar(255) NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- 转存表中的数据 `miaosha`
--

INSERT INTO `miaosha` (`sid`, `url`, `title`, `price`, `preprice`) VALUES
(1, 'http://img3m9.ddimg.cn/89/23/1296367469-1_u_1.jpg,http://img3m9.ddimg.cn/89/23/1296367469-2_u_1.jpg,http://img3m9.ddimg.cn/89/23/1296367469-3_u_1.jpg,http://img3m9.ddimg.cn/89/23/1296367469-4_u_1.jpg,http://img3m9.ddimg.cn/89/23/1296367469-5_u_1.jpg', '【11日10点秒杀价53.8】韩纪蜗牛原液面部护理六件套控油补水保湿护肤套装', '53.8', '￥129'),
(2, 'http://img3m4.ddimg.cn/71/0/25217054-1_u_3.jpg,http://img3m4.ddimg.cn/71/0/25217054-2_u_3.jpg,http://img3m4.ddimg.cn/71/0/25217054-3_u_3.jpg', '钢铁是怎样炼成的（2018新版 中小学新课标必读名著）', '19', '￥31'),
(3, 'http://img3m0.ddimg.cn/75/36/1370851590-1_u_1.jpg', '安踏男装运动短裤 2018夏季新款速干吸汗透气健身跑步五分运动裤', '55', '￥62'),
(4, 'http://img3m9.ddimg.cn/31/36/410261179-1_u_2.jpg,http://img3m9.ddimg.cn/31/36/410261179-2_u_1.jpg,http://img3m9.ddimg.cn/31/36/410261179-3_u_1.jpg,http://img3m9.ddimg.cn/31/36/410261179-4_u_1.jpg,http://img3m9.ddimg.cn/31/36/410261179-5_u_1.jpg', '当当优品 天然竹席 双人席子 可折叠碳化镜面夏凉席', '79', '￥399'),
(5, 'http://img3m1.ddimg.cn/13/10/25211551-1_u_1.jpg,http://img3m1.ddimg.cn/13/10/25211551-2_u_1.jpg,http://img3m1.ddimg.cn/13/10/25211551-3_u_1.jpg,http://img3m1.ddimg.cn/13/10/25211551-4_u_1.jpg', '海底两万里（2018新版 中小学新课标必读名著）', '16', '￥26'),
(6, 'http://img3m7.ddimg.cn/16/29/1440441997-1_u_1.jpg,http://img3m7.ddimg.cn/16/29/1440441997-2_u_1.jpg,http://img3m7.ddimg.cn/16/29/1440441997-3_u_1.jpg,http://img3m7.ddimg.cn/16/29/1440441997-4_u_1.jpg,http://img3m7.ddimg.cn/16/29/1440441997-5_u_1.jpg', '【秒杀款 限购一件】童装男童沙滩裤 夏新款中大童格子韩版潮休闲中裤儿童五分裤', '38', '￥79'),
(7, 'http://img3m5.ddimg.cn/86/11/410263115-1_u_1.jpg', '中小学生必读国学经典（新课标全套3册：史记+资治通鉴+孙子兵法.三十六计）', '25.6', '￥37'),
(8, 'http://img3m8.ddimg.cn/36/34/1280994498-1_u_4.jpg,http://img3m8.ddimg.cn/36/34/1280994498-2_u_1.jpg,http://img3m8.ddimg.cn/36/34/1280994498-3_u_1.jpg,http://img3m8.ddimg.cn/36/34/1280994498-4_u_1.jpg,http://img3m8.ddimg.cn/36/34/1280994498-5_u_1.jpg', '【超值秒杀 仅此一天】门扉 电脑桌 可折叠笔记本桌懒人学生宿舍床上用简约小桌子学习桌', '29', '￥39'),
(9, 'http://img3m0.ddimg.cn/30/25/1039722780-1_u_2.jpg,http://img3m0.ddimg.cn/30/25/1039722780-2_u_2.jpg,http://img3m0.ddimg.cn/30/25/1039722780-3_u_2.jpg,http://img3m0.ddimg.cn/30/25/1039722780-4_u_2.jpg', '依曼丽性感蕾丝无钢圈文胸 大胸包容聚拢调整型女士内衣7127', '49', '￥139'),
(10, 'http://img3m2.ddimg.cn/40/35/23950912-1_u_8.jpg,http://img3m2.ddimg.cn/40/35/23950912-2_u_12.jpg,http://img3m2.ddimg.cn/40/35/23950912-3_u_10.jpg,http://img3m2.ddimg.cn/40/35/23950912-4_u_10.jpg,http://img3m2.ddimg.cn/40/35/23950912-5_u_14.jpg', '多莱尔的希腊神话书（畅销千万册，纽约公共图书馆“百年百佳书”）', '39.6', '￥66');

-- --------------------------------------------------------

--
-- 表的结构 `miaosha_right`
--

CREATE TABLE IF NOT EXISTS `miaosha_right` (
  `sid` tinyint(4) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `miaosha_right`
--

INSERT INTO `miaosha_right` (`sid`, `url`) VALUES
(1, 'http://img63.ddimg.cn/2018/6/8/2018060814340730556.jpg'),
(2, 'http://img60.ddimg.cn/2018/6/8/2018060816224292411.jpg'),
(3, 'http://img63.ddimg.cn/2018/6/8/2018060817152797416.jpg'),
(4, 'http://img63.ddimg.cn/2018/6/8/2018060817163534121.jpg'),
(5, 'http://img63.ddimg.cn/2018/6/8/2018060816242646573.jpg'),
(6, 'http://img63.ddimg.cn/2018/6/8/2018060817383325990.jpg'),
(7, 'http://img61.ddimg.cn/2018/6/8/2018060817413652534.jpg'),
(8, 'http://img63.ddimg.cn/2018/6/8/2018060817170659019.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `userifo`
--

CREATE TABLE IF NOT EXISTS `userifo` (
  `sid` tinyint(4) unsigned NOT NULL AUTO_INCREMENT,
  `tel` varchar(100) NOT NULL,
  `password` varchar(40) NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- 转存表中的数据 `userifo`
--

INSERT INTO `userifo` (`sid`, `tel`, `password`) VALUES
(2, '12345678910', 'e10adc3949ba59abbe56e057f20f883e'),
(3, '13456183833', '99279af38660cdae8a49141d05c8c9c2'),
(4, '12346578902', 'e10adc3949ba59abbe56e057f20f883e'),
(5, '12323234111', 'e10adc3949ba59abbe56e057f20f883e'),
(6, '12345632411', 'e10adc3949ba59abbe56e057f20f883e'),
(7, '15869393926', '194815a778b55e72fdc4b0d1c0ef216a'),
(8, '12345678903', 'c773fd2aa64b6fc98374d99e3af94e95'),
(9, '12345678909', 'e10adc3949ba59abbe56e057f20f883e'),
(10, '12345678911', 'e10adc3949ba59abbe56e057f20f883e'),
(11, '12346578915', 'e10adc3949ba59abbe56e057f20f883e'),
(12, '12345678955', 'e10adc3949ba59abbe56e057f20f883e'),
(13, '12345678966', 'e10adc3949ba59abbe56e057f20f883e'),
(14, '12345678999', 'e10adc3949ba59abbe56e057f20f883e');
